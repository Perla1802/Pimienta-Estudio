# PIMIENTA ESTUDIO DE DISEÑO

Este proyecto esta desarrollado usando `Vite` y `React`.
Para poder inicializar el proyecto debes de ejecutar:

    $ npm install
    $ npm run dev

![Portada Pimienta](./public/portada.png)

Desarrollado por **_[Perla Y. Hernández](https://github.com/Perla1802)_** y **_[David Galavíz](https://github.com/Davix00)_**.
